Overdriven.fr - Free Guitar Cab Impulse Responses
-------------------------------------------------
This directory contains free guitar contains impulse responses from overdriven.fr (https://overdriven.fr). Visit https://overdriven.fr/overdriven/index.php/irdownloads/ for IR capture information.

Collection Version : 1.0

Cab 		: German 112 (1*12)
Speaker 	: Celestion(r) G12-65, 8 ohms
Power amp 	: KT88 
Mic preamp	: TubePreamp2

Microphones : 11
IR files    : 98

Microphones included : DYN-57 DYN-US-6 DYN-AT-1 DYN-AT-2 DYN-R20 RBN-DE-2 RBN-CN-1 RBN-CN-2 DYN-I5 DYN-7B DYN-CN-7 


Format is WAV 44,1 kHz, 32 bits floating point. IRs length is 50 milliseconds . 

Terms of use
------------
Overdriven.fr provides free audio impulse response files. These files remain the entire property of overdriven.fr / David. A. THESE FILES ARE PROVIDED « AS-IS ». overdriven.fr SHALL NOT BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR EXEMPLARY DAMAGES OR LOSSES ARISING FROM THE USE OF, INABILITY TO USE THE impulse response files. THESE EXCLUSIONS APPLY TO ANY CLAIMS FOR LOST PROFITS, LOST DATA, LOSS OF GOODWILL, WORK STOPPAGE, COMPUTER FAILURE OR MALFUNCTION, OR ANY OTHER COMMERCIAL DAMAGES OR LOSSES, EVEN IF OVERDRIVEN.FR KNEW OR SHOULD HAVE KNOWN OF THE POSSIBILITY OF SUCH DAMAGES 

Users are free to use these impulse files in the context of musical or video creations, free of rights, and this for any commercial or non-commercial purpose. 

It is expressly forbidden to host these files on other websites, or through any file sharing systems. Reselling these files is forbidden. Audio software or hardware vendors are not allowed to distribute these files with their products without a written agreement from the owner of overdriven.fr. 


Generated : dim. mars 06 16:51:21 CET 2022